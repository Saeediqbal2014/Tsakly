<!--Proect_Details_Start-->
<div class="pr-4 pl-4">

    <div class="container">

        <div class="row">
            <div class="col-lg-6">
                <a></a><span class="Page_Title">Balance</span>
            </div>
        </div>


        <div class="row mt-4">
            <div class="col-sm-3 card p-5">
                <h6>Current Balance </h6>
                <h3>Rs.200</h3>
            </div>
        </div>


    </div>

</div>